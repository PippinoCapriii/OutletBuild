package it.unisa.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class UserDAO implements UserDAOInterfaccia {

    private static DataSource ds;

    static {
        try {
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");

            ds = (DataSource) envCtx.lookup("jdbc/storage");

        } catch (NamingException e) {
            System.out.println("Error:" + e.getMessage());
        }
    }

    private static final String TABLE_NAME = "cliente";

    @Override
    public synchronized void doSave(UserBean user) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String insertSQL = "INSERT INTO " + UserDAO.TABLE_NAME
                + " (NOME, COGNOME, USERNAME, PWD, EMAIL, DATA_NASCITA, CARTA_CREDITO, INDIRIZZO, CAP, AMMINISTRATORE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

        try {
            connection = ds.getConnection();
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(insertSQL);
            preparedStatement.setString(1, user.getNome());
            preparedStatement.setString(2, user.getCognome());
            preparedStatement.setString(3, user.getUsername());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setString(5, user.getEmail());
            preparedStatement.setDate(6, (Date) user.getDataDiNascita());
            preparedStatement.setString(7, user.getCartaDiCredito());
            preparedStatement.setString(8, user.getIndirizzo());
            preparedStatement.setString(9, user.getCap());
            preparedStatement.setBoolean(10, user.isAmministratore());

            preparedStatement.executeUpdate();

            connection.commit();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                if (connection != null)
                    connection.close();
            }
        }
    }

    @Override
    public synchronized UserBean doRetrieve(String username, String password) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        UserBean user = new UserBean();

        String searchQuery = "SELECT * FROM " + UserDAO.TABLE_NAME
                + " WHERE USERNAME = ? AND PWD = ? ";

        try {
            connection = ds.getConnection();
            preparedStatement = connection.prepareStatement(searchQuery);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet rs = preparedStatement.executeQuery();
            boolean more = rs.next();

            if (!more) {
                user.setValid(false);
            } else {
                user.setUsername(rs.getString("USERNAME"));
                user.setPassword(rs.getString("PWD"));
                user.setEmail(rs.getString("EMAIL"));
                user.setNome(rs.getString("NOME"));
                user.setCognome(rs.getString("COGNOME"));
                user.setDataDiNascita(rs.getDate("DATA_NASCITA"));
                user.setCartaDiCredito(rs.getString("CARTA_CREDITO"));
                user.setIndirizzo(rs.getString("INDIRIZZO"));
                user.setCap(rs.getString("CAP"));
                user.setAmministratore(rs.getBoolean("AMMINISTRATORE"));
                user.setValid(true);
            }
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                if (connection != null)
                    connection.close();
            }
        }

        return user;
    }

    @Override
    public synchronized ArrayList<UserBean> doRetrieveAll(String order) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        ArrayList<UserBean> users = new ArrayList<UserBean>();

        String selectSQL = "SELECT * FROM " + UserDAO.TABLE_NAME;

        if (order != null && !order.equals("")) {
            selectSQL += " ORDER BY " + order;
        }

        try {
            connection = ds.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                UserBean user = new UserBean();
                user.setUsername(rs.getString("USERNAME"));
                user.setPassword(rs.getString("PWD"));
                user.setEmail(rs.getString("EMAIL"));
                user.setNome(rs.getString("NOME"));
                user.setCognome(rs.getString("COGNOME"));
                user.setDataDiNascita(rs.getDate("DATA_NASCITA"));
                user.setCartaDiCredito(rs.getString("CARTA_CREDITO"));
                user.setIndirizzo(rs.getString("INDIRIZZO"));
                user.setCap(rs.getString("CAP"));
                user.setAmministratore(rs.getBoolean("AMMINISTRATORE"));
                user.setValid(true);
                users.add(user);
            }
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                if (connection != null)
                    connection.close();
            }
        }

        return users;
    }

    @Override
    public synchronized void doUpdateSpedizione(String email, String indirizzo, String cap) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String updateSQL = "UPDATE " + UserDAO.TABLE_NAME
                + " SET INDIRIZZO = ?, CAP = ?"
                + " WHERE EMAIL = ? ";

        try {
            connection = ds.getConnection();
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(updateSQL);
            preparedStatement.setString(1, indirizzo);
            preparedStatement.setString(2, cap);
            preparedStatement.setString(3, email);
            preparedStatement.executeUpdate();

            connection.commit();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                if (connection != null)
                    connection.close();
            }
        }
    }

    @Override
    public synchronized void doUpdatePagamento(String email, String carta) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String updateSQL = "UPDATE " + UserDAO.TABLE_NAME
                + " SET CARTA_CREDITO = ?"
                + " WHERE EMAIL = ? ";

        try {
            connection = ds.getConnection();
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(updateSQL);
            preparedStatement.setString(1, carta);
            preparedStatement.setString(2, email);
            preparedStatement.executeUpdate();

            connection.commit();
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                if (connection != null)
                    connection.close();
            }
        }
    }
}
